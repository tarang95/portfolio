module.exports = {
    url: 'mongodb://bhumi:bhumi031@ds229609.mlab.com:29609/citylogs'
}